// E2K 대화 저장 (프로토타입 v0.8)
// 화면에 표시된 대화 원문을 위에서부터 스크롤하며 모아 .md 파일로 저장한다.
// SNOWCHAT은 화면이 쓰는 같은 사이트 주소에서 대화 기록을 읽어 온다 (외부 서버로는 아무것도 보내지 않음).
// 모든 처리는 이 브라우저 탭 안에서만 일어난다.

(() => {
  if (window.__e2kCaptureLoaded) return;
  window.__e2kCaptureLoaded = true;

  const HOST = location.hostname;
  const SITE = HOST.includes("claude.ai")
    ? "claude"
    : HOST === "gemini.google.com"
    ? "gemini"
    : HOST.endsWith("factchat.bot")
    ? "snowchat"
    : "chatgpt";
  const SITE_LABEL = { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini", snowchat: "SNOWCHAT" }[SITE];
  let cancelRequested = false; // 저장 중 버튼을 다시 누르면 true
  let partialReason = null; // 끝까지 못 모았을 때 이유
  let captureMethod = "화면에 표시된 원문을 스크롤하며 수집"; // 파일 머리에 적는 수집 방식
  let skippedNotes = 0; // 대화 요약 표시처럼 메시지가 아니어서 뺀 줄 수
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- SNOWCHAT ----------
  // 대화 주소: /dashboard/chat/{에이전트ID}/{세션ID}

  const SNOW_SUMMARY = /^여기까지의 대화를 요약했습니다/;

  function snowSessionId() {
    return (location.pathname.match(/\/dashboard\/chat\/[^/]+\/([\w-]+)/) || [])[1] || null;
  }

  function snowTitle() {
    const el = document.querySelector('[data-scope="editable"][data-part="preview"]');
    return (el && el.textContent.trim()) || null;
  }

  function snowFileLine(files) {
    // 파일 주소는 기간이 지나면 만료되고 개인 자료일 수 있어 이름과 종류만 남긴다.
    const names = (files || [])
      .filter((f) => f && f.name)
      .map((f) => `${f.name}${f.type ? ` (${f.type})` : ""}${f.is_expired ? " · 만료됨" : ""}`);
    return names.length ? `\n\n[첨부·출력 파일] ${names.join(", ")}` : "";
  }

  // 방법 1: 화면이 쓰는 대화 기록 주소로 읽기 (위로 스크롤하지 않아도 전체를 순서대로 받음)
  async function captureSnowchatApi(setStatus) {
    const sid = snowSessionId();
    if (!sid) throw new Error("대화 주소에서 세션 번호를 찾지 못했어요.");
    const startUrl = location.pathname;
    let all = [];
    let firstId = null;
    for (let page = 0; page < 100; page++) {
      if (cancelRequested) {
        partialReason = "사용자가 중간에 멈췄어요";
        break;
      }
      if (location.pathname !== startUrl)
        throw new Error("저장 중에 다른 대화로 이동했어요. 이 대화에서 다시 눌러 주세요.");
      setStatus(`불러오는 중… 메시지 ${all.length}개 (누르면 멈춤)`);
      const q = new URLSearchParams({ size: "100" });
      if (firstId) q.set("first_id", firstId);
      const res = await fetch(`/api/proxy/sessions/${encodeURIComponent(sid)}/history?${q}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error(`대화 기록 주소 응답 ${res.status}`);
      const json = await res.json();
      const data = json && json.data;
      if (!data || !Array.isArray(data.history_list)) throw new Error("대화 기록 형식이 예상과 달라요");
      all = [...data.history_list, ...all]; // 받은 쪽이 더 이전 메시지라 앞에 붙임
      const pg = data.pagination || {};
      if (!pg.has_next_page || !pg.filter_value || pg.filter_value === firstId) break;
      firstId = pg.filter_value;
      if (page === 99) partialReason = "기록이 너무 길어 앞부분 일부를 받지 못했어요";
      await sleep(300);
    }

    const seen = new Set();
    const list = [];
    for (const m of all) {
      if (!m || (m.id && seen.has(m.id))) continue;
      if (m.id) seen.add(m.id);
      const role = m.speaker_type === "user" ? "user" : "assistant";
      const body = (m.text || "").trim();
      if (role === "user" && SNOW_SUMMARY.test(body)) {
        skippedNotes++;
        continue;
      }
      const text = (body + snowFileLine(m.file_list)).trim();
      if (!text) continue;
      list.push({ role, text });
    }
    if (!list.length) throw new Error("받은 대화 기록이 비어 있어요");
    captureMethod = "SNOWCHAT 화면이 쓰는 대화 기록 주소에서 원문을 읽어 수집";
    return list;
  }

  // 방법 2: 화면에서 읽기 (방법 1이 막혔을 때)
  function snowMessages() {
    const nodes = [...document.querySelectorAll('[data-message-role="user"], [data-message-role="assistant"]')];
    const outer = nodes.filter((n) => !nodes.some((m) => m !== n && m.contains(n)));
    return outer.map((el) => {
      const role = el.getAttribute("data-message-role") === "user" ? "user" : "assistant";
      const idEl = el.matches("[data-message-id]") ? el : el.querySelector("[data-message-id]");
      return { el, role, key: idEl ? idEl.getAttribute("data-message-id") : null };
    });
  }

  function snowText(el, role) {
    const c = el.cloneNode(true);
    c.querySelectorAll('[data-copy-exclude="true"], button, svg').forEach((n) => n.remove());
    // 출력 파일 카드는 파일 이름만 남긴다
    const cards = [...el.querySelectorAll('[data-artifact-id^="file-preview-"]')];
    c.querySelectorAll('[data-artifact-id^="file-preview-"]').forEach((n) => n.remove());
    let text = (c.innerText || c.textContent || "").replace(/\n{3,}/g, "\n\n").trim();
    if (role === "user") {
      text = text.replace(/\d{4}년\s*\d{1,2}월\s*\d{1,2}일\s*오[전후]\s*\d{1,2}:\d{2}/g, "").trim();
    }
    const FILE_NAME = /[^\s\\/:*?"<>|]+\.(md|txt|pdf|docx?|pptx?|xlsx?|csv|hwpx?|png|jpe?g|gif|json|html?|zip)(?![\w.])/i;
    const names = cards
      .map((n) => ((n.textContent || "").match(FILE_NAME) || [])[0])
      .filter(Boolean);
    if (names.length) text += `\n\n[첨부·출력 파일] ${names.join(", ")}`;
    return text;
  }

  // ---------- 사이트별 메시지 찾기 ----------

  // ChatGPT (2026.10 화면 구조): 질문 하나와 답 하나가 [data-turn-key] 턴으로 묶여 있다.
  // 질문은 [data-user-message-bubble], 화면 낭독용 제목(h4.sr-only)은 제외한다.
  // 지금 주소의 대화 ID. 다른 대화에서 넘어왔을 때 남아 있던 턴을 걸러내는 데 쓴다.
  function currentConversationId() {
    return (location.pathname.match(/\/c\/([0-9a-f-]+)/i) || [])[1] || null;
  }

  function visibleScroller() {
    const all = [...document.querySelectorAll("[data-app-action-timeline-scroll]")];
    return all.find((s) => s.offsetParent) || all[0] || null;
  }

  function chatgptTurns() {
    const id = currentConversationId();
    const sc = visibleScroller();
    return [...document.querySelectorAll("[data-turn-key]")].filter((t) => {
      if (sc && !sc.contains(t)) return false; // 화면에 보이는 대화창 안의 턴만
      const tag = t.querySelector("[data-chatgpt-selection-conversation-id]");
      if (id && tag && tag.getAttribute("data-chatgpt-selection-conversation-id") !== id) return false; // 다른 대화의 턴 제외
      return true;
    });
  }

  function splitTurn(turn) {
    const full = turn.innerText || "";
    const bubble = turn.querySelector("[data-user-message-bubble]");
    const user = bubble ? (bubble.innerText || "").trim() : "";
    let rest = full;
    if (user) {
      const i = rest.indexOf(user);
      if (i >= 0) rest = rest.slice(0, i) + rest.slice(i + user.length);
    }
    const heads = [...turn.querySelectorAll("h1,h2,h3,h4,h5,h6")]
      .filter((h) => h.classList.contains("sr-only") || h.hasAttribute("data-conversation-role"))
      .map((h) => (h.innerText || "").trim())
      .filter(Boolean);
    for (const h of heads) {
      const i = rest.indexOf(h);
      if (i >= 0) rest = rest.slice(0, i) + rest.slice(i + h.length);
    }
    return { user, assistant: rest.replace(/\n{3,}/g, "\n\n").trim() };
  }

  async function captureChatgptTurns(setStatus) {
    const first = chatgptTurns()[0];
    const scroller = visibleScroller() || findScroller(first);
    const keys = () => chatgptTurns().map((t) => t.getAttribute("data-turn-key"));
    const startUrl = location.pathname;
    const checkUrl = () => {
      if (location.pathname !== startUrl)
        throw new Error("저장 중에 다른 대화로 이동했어요. 이 대화에서 다시 눌러 주세요.");
    };

    // 1) 맨 위로: 첫 턴과 전체 높이가 5초 연속 그대로일 때까지 (이전 기록을 다 불러올 시간을 줌)
    setStatus("맨 위까지 올라가는 중…");
    let same = 0;
    let prevFirst = null;
    let prevH = -1;
    for (let i = 0; i < 600 && same < 5; i++) {
      checkUrl();
      if (cancelRequested) break;
      scroller.scrollTop = 0;
      await sleep(1000);
      const f = keys()[0];
      const h = scroller.scrollHeight;
      same = f === prevFirst && h === prevH && scroller.scrollTop === 0 ? same + 1 : 0;
      prevFirst = f;
      prevH = h;
    }

    // 2) 아래로: 화면의 마지막 턴을 위로 올리며 다음 턴을 불러온다 (건너뛰는 턴이 생기지 않도록)
    const seen = new Map(); // key -> {user, assistant, order}
    let order = 0;
    const collect = () => {
      for (const t of chatgptTurns()) {
        const k = t.getAttribute("data-turn-key");
        const { user, assistant } = splitTurn(t);
        const prev = seen.get(k);
        if (!prev) seen.set(k, { user, assistant, order: order++ });
        else {
          if (user.length > prev.user.length) prev.user = user;
          if (assistant.length > prev.assistant.length) prev.assistant = assistant;
        }
      }
    };
    // 새 턴이 나타나면 그 턴 맨 위로 이동하고,
    // 같은 턴이 계속 마지막이면(답변이 화면보다 긴 경우) 그 자리에서 한 화면씩 계속 내려간다.
    let doneCount = 0;
    let prevLast = null;
    const started = Date.now();
    for (let i = 0; i < 20000 && doneCount < 3; i++) {
      checkUrl();
      if (cancelRequested) break;
      if (Date.now() - started > 20 * 60 * 1000) {
        partialReason = "20분이 지나 저장을 멈췄어요";
        break;
      }
      collect();
      setStatus(`모으는 중… ${seen.size}턴 (누르면 멈춤)`);
      const ts = chatgptTurns();
      const lastNow = ts.length ? ts[ts.length - 1].getAttribute("data-turn-key") : null;
      if (lastNow !== prevLast && ts.length) ts[ts.length - 1].scrollIntoView({ block: "start" });
      else scroller.scrollTop += Math.floor(scroller.clientHeight * 0.8);
      prevLast = lastNow;
      await sleep(800);
      collect();
      const lastAfter = keys().slice(-1)[0];
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 5;
      doneCount = atBottom && lastAfter === lastNow ? doneCount + 1 : 0;
    }
    if (cancelRequested) partialReason = "사용자가 중간에 멈췄어요";

    const list = [];
    for (const t of [...seen.values()].sort((a, b) => a.order - b.order)) {
      if (t.user) list.push({ role: "user", text: t.user });
      if (t.assistant) list.push({ role: "assistant", text: t.assistant });
    }
    return list;
  }

  function findMessages() {
    if (SITE === "snowchat") return snowMessages();
    if (SITE === "gemini") return geminiMessages();
    if (SITE === "chatgpt") {
      // 예전 화면 구조 (대비용)
      return [...document.querySelectorAll("[data-message-author-role]")].map((el) => ({
        el,
        role: el.getAttribute("data-message-author-role") === "user" ? "user" : "assistant",
        key: el.getAttribute("data-message-id") || null,
      }));
    }
    // Claude: 사용자 메시지와 응답 메시지 후보를 문서 순서대로 모은다.
    const USER_SEL = '[data-testid="user-message"]';
    // AI 답변 후보 중 내 메시지를 품고 있는 큰 묶음은 뺀다
    const nodes = [...document.querySelectorAll(USER_SEL + ", " + CLAUDE_AI_SEL)].filter(
      (n) => n.matches(USER_SEL) || !n.querySelector(USER_SEL)
    );
    // 바깥 요소만 남긴다 (중첩 중복 제거)
    const outer = nodes.filter((n) => !nodes.some((m) => m !== n && m.contains(n)));
    outer.sort((a, b) =>
      a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
    );
    return outer.map((el) => ({
      el,
      role: el.matches('[data-testid="user-message"]') ? "user" : "assistant",
      key: null,
    }));
  }

  function findScroller(sample) {
    let el = sample ? sample.parentElement : null;
    while (el && el !== document.body) {
      const s = getComputedStyle(el);
      if (/(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 10) {
        return el;
      }
      el = el.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function textOf(el) {
    return (el.innerText || "").replace(/\n{3,}/g, "\n\n").trim();
  }

  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return String(h >>> 0);
  }

  // ---------- Gemini ----------
  // 한 번 주고받은 대화 = div.conversation-container (id = 턴 키)
  // 내 메시지 = user-query, AI 답 = model-response message-content .markdown

  const GEM_SCROLLER = 'infinite-scroller[data-test-id="chat-history-container"]';
  const GEM_STRIP = [
    ".cdk-visually-hidden",
    "source-footnote",
    "source-inline-chip",
    "sources-carousel-inline",
    "sources-list",
    "message-actions",
    "copy-button",
    "thumb-up-button",
    "thumb-down-button",
    "regenerate-button",
    "model-response-disclaimers",
    '[class*="-disclaimer"]',
    "sensitive-memories-banner",
    "response-info-line",
    "thinking-overlay",
    '[data-test-id$="-button"]',
    '[data-test-id^="luminous-expand"]',
    '[data-test-id^="luminous-collapse"]',
    "button",
    "mat-icon",
  ].join(", ");

  function geminiMessages() {
    const out = [];
    for (const turn of document.querySelectorAll(".conversation-container")) {
      const key = turn.id || null;
      const u = turn.querySelector("user-query");
      const a = turn.querySelector("model-response");
      if (u) out.push({ el: u, role: "user", key: key ? key + ":u" : null });
      if (a) out.push({ el: a, role: "assistant", key: key ? key + ":a" : null });
    }
    return out;
  }

  // 화면에서 떼어 낸 복사본은 줄바꿈 정보가 사라지므로, 요소 종류를 보고 직접 글로 옮긴다.
  function blockText(node) {
    if (node.nodeType === Node.TEXT_NODE) return node.nodeValue.replace(/\s+/g, " ");
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const tag = node.tagName.toLowerCase();
    if (tag === "code-block" || tag === "pre") {
      const code = node.querySelector('[data-test-id="code-content"]') || node.querySelector("code") || node;
      return "\n```\n" + (code.textContent || "").replace(/\n+$/, "") + "\n```\n";
    }
    if (tag === "br") return "\n";
    const inner = [...node.childNodes].map(blockText).join("");
    if (/^h[1-6]$/.test(tag)) return "\n\n" + "#".repeat(+tag[1]) + " " + inner.trim() + "\n\n";
    if (tag === "li") {
      const parent = node.parentElement;
      if (parent && parent.tagName.toLowerCase() === "ol") {
        const start = parseInt(parent.getAttribute("start") || "1", 10) || 1;
        const idx = [...parent.children].filter((c) => c.tagName.toLowerCase() === "li").indexOf(node);
        return "\n" + (start + idx) + ". " + inner.trim();
      }
      return "\n- " + inner.trim();
    }
    if (tag === "p" && node.classList.contains("query-text-line")) return "\n" + inner.replace(/\s+$/, "");
    if (tag === "strong" || tag === "b") return inner.trim() ? "**" + inner.trim() + "**" : "";
    if (tag === "td" || tag === "th") return " " + inner.trim() + " |";
    if (tag === "tr") return "\n|" + inner;
    if (/^(p|div|ul|ol|table|blockquote|section|hr)$/.test(tag)) return "\n" + inner + "\n";
    return inner;
  }

  function tidy(s) {
    return s
      .split("\n")
      .map((l) => l.replace(/[ \t]+$/g, "").replace(/^ (?=\S)/, ""))
      .join("\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function geminiText(el, role) {
    const c = el.cloneNode(true);
    let files = [];
    if (role === "user") {
      files = [...c.querySelectorAll('[data-test-id="filename-label"]')]
        .map((n) => n.textContent.trim())
        .filter(Boolean);
      c.querySelectorAll('user-query-file-carousel, [data-test-id="uploaded-file"]').forEach((n) => n.remove());
    }
    c.querySelectorAll(GEM_STRIP).forEach((n) => n.remove());
    let text;
    if (role === "user") {
      // 내 메시지 영역 전체를 순서대로 읽는다 (한 줄 문단뿐 아니라 목록·표·코드도 포함)
      text = tidy(blockText(c.querySelector(".query-text") || c));
    } else {
      const body = c.querySelector("message-content .markdown") || c.querySelector("message-content") || c;
      text = tidy(blockText(body));
    }
    text = text.trim();
    if (files.length) text += `\n\n[첨부 파일] ${files.join(", ")}`;
    return text;
  }

  function geminiTitle() {
    const t = (document.title || "").replace(/\s*[-–|]\s*(Google\s+)?Gemini\s*$/i, "").trim();
    if (t && !/^(Google\s+)?Gemini$/i.test(t)) return t;
    const first = document.querySelector(".conversation-container user-query p.query-text-line");
    return first ? "Gemini_" + first.textContent.trim().slice(0, 30) : null;
  }

  // ---------- Claude ----------
  // 대화 주소: /chat/{대화ID}
  // 1순위: Claude 화면이 쓰는 같은 사이트의 대화 기록 주소에서 읽기 (화면 표시 방식이 바뀌어도 영향이 적음)
  // 2순위: 화면에서 읽기

  function claudeConvId() {
    return (location.pathname.match(/\/chat\/([0-9a-f-]{36})/i) || [])[1] || null;
  }

  function claudeOrgCandidates() {
    const m = document.cookie.match(/(?:^|;\s*)lastActiveOrg=([^;]+)/);
    return m ? [decodeURIComponent(m[1])] : [];
  }

  async function claudeJson(url) {
    const res = await fetch(url, { credentials: "include", headers: { accept: "application/json" } });
    if (!res.ok) throw new Error(`대화 기록 주소 응답 ${res.status}`);
    return res.json();
  }

  function claudeMsgText(m) {
    let text = "";
    if (Array.isArray(m.content) && m.content.length) {
      text = m.content
        .filter((c) => c && c.type === "text" && typeof c.text === "string")
        .map((c) => c.text)
        .join("\n\n");
    }
    if (!text && typeof m.text === "string") text = m.text;
    const files = [...(m.attachments || []), ...(m.files || []), ...(m.files_v2 || [])]
      .map((f) => f && (f.file_name || f.name))
      .filter(Boolean);
    text = text.trim();
    if (files.length) text += `\n\n[첨부 파일] ${[...new Set(files)].join(", ")}`;
    return text.trim();
  }

  async function captureClaudeApi(setStatus) {
    const conv = claudeConvId();
    if (!conv) throw new Error("대화 주소에서 대화 번호를 찾지 못했어요.");
    setStatus("대화 기록 불러오는 중…");
    let orgs = claudeOrgCandidates();
    if (!orgs.length) {
      const list = await claudeJson("/api/organizations");
      orgs = (Array.isArray(list) ? list : []).map((o) => o && o.uuid).filter(Boolean);
    }
    let data = null;
    let lastErr = null;
    for (const org of orgs) {
      try {
        data = await claudeJson(
          `/api/organizations/${encodeURIComponent(org)}/chat_conversations/${encodeURIComponent(conv)}` +
            "?tree=True&rendering_mode=messages&render_all_tools=true"
        );
        break;
      } catch (e) {
        lastErr = e;
      }
    }
    if (!data) throw lastErr || new Error("조직 정보를 찾지 못했어요");
    const all = Array.isArray(data.chat_messages) ? data.chat_messages : [];
    if (!all.length) throw new Error("받은 대화 기록이 비어 있어요");

    // 대화를 고쳐 다시 보낸 적이 있으면 갈래가 여러 개라, 지금 화면에 보이는 갈래만 따라간다.
    const byId = new Map(all.map((m) => [m.uuid, m]));
    let chain = [];
    if (data.current_leaf_message_uuid && byId.has(data.current_leaf_message_uuid)) {
      const guard = new Set();
      for (let m = byId.get(data.current_leaf_message_uuid); m && !guard.has(m.uuid); m = byId.get(m.parent_message_uuid)) {
        guard.add(m.uuid);
        chain.push(m);
      }
      chain.reverse();
    } else {
      chain = [...all].sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
    }

    const list = [];
    for (const m of chain) {
      const text = claudeMsgText(m);
      if (!text) continue;
      list.push({ role: m.sender === "human" ? "user" : "assistant", text });
    }
    if (!list.length) throw new Error("대화 기록에서 글을 찾지 못했어요");
    captureMethod = "Claude 화면이 쓰는 대화 기록 주소에서 원문을 읽어 수집";
    return list;
  }

  // 화면에서 읽을 때 AI 답변 후보 (화면 구조가 바뀌어 온 이력이 있어 여러 표시를 함께 찾는다)
  const CLAUDE_AI_SEL = [
    ".font-claude-response",
    ".font-claude-message",
    '[data-testid="assistant-message"]',
    '[data-testid="claude-message"]',
    "[data-is-streaming]",
  ].join(", ");

  // ---------- 수집 ----------

  async function capture(setStatus) {
    if (SITE === "chatgpt" && chatgptTurns().length) return captureChatgptTurns(setStatus);
    if (SITE === "claude" && claudeConvId()) {
      try {
        return await captureClaudeApi(setStatus);
      } catch (e) {
        if (cancelRequested) throw e;
        console.warn("E2K: Claude 대화 기록 주소로 읽지 못해 화면에서 읽어요 —", e.message);
        partialReason = null;
        captureMethod = "화면에 표시된 원문을 스크롤하며 수집 (대화 기록 주소로 읽기 실패)";
      }
    }
    if (SITE === "snowchat") {
      if (!snowSessionId())
        throw new Error("SNOWCHAT 대화 화면(주소가 /dashboard/chat/…)을 연 상태에서 눌러 주세요.");
      try {
        return await captureSnowchatApi(setStatus);
      } catch (e) {
        if (cancelRequested) throw e;
        console.warn("E2K: 대화 기록 주소로 읽지 못해 화면에서 읽어요 —", e.message);
        partialReason = null;
        skippedNotes = 0;
        captureMethod = "화면에 표시된 원문을 스크롤하며 수집 (대화 기록 주소로 읽기 실패)";
      }
    }
    let msgs = findMessages();
    if (!msgs.length) throw new Error("이 화면에서 대화 메시지를 찾지 못했어요. 대화창을 연 상태에서 눌러 주세요.");
    const scroller =
      (SITE === "snowchat" && document.querySelector("[data-chat-scroll-container]")) ||
      (SITE === "gemini" && document.querySelector(GEM_SCROLLER)) ||
      findScroller(msgs[0].el);

    // 1) 맨 위까지 올라가며 이전 메시지를 모두 불러온다.
    setStatus("맨 위까지 올라가는 중…");
    let stable = 0;
    let lastHeight = -1;
    for (let i = 0; i < 300 && stable < 4; i++) {
      if (cancelRequested) break;
      scroller.scrollTop = 0;
      await sleep(700);
      const h = scroller.scrollHeight;
      if (h === lastHeight && scroller.scrollTop === 0) stable++;
      else stable = 0;
      lastHeight = h;
    }

    // 2) 위에서 아래로 내려가며 화면에 나타나는 메시지를 순서대로 담는다.
    const seen = new Map(); // key -> {role, text, order}
    let order = 0;
    const collect = () => {
      for (const m of findMessages()) {
        const text =
          SITE === "snowchat" ? snowText(m.el, m.role) : SITE === "gemini" ? geminiText(m.el, m.role) : textOf(m.el);
        if (!text) continue;
        if (SITE === "snowchat" && m.role === "user" && SNOW_SUMMARY.test(text)) continue;
        const key = m.key || m.role + ":" + hash(text);
        const prev = seen.get(key);
        if (!prev) seen.set(key, { role: m.role, text, order: order++ });
        else if (text.length > prev.text.length) prev.text = text; // 덜 그려졌던 경우 더 긴 것으로
      }
    };

    const step = Math.max(200, Math.floor(scroller.clientHeight * 0.7));
    let atBottomCount = 0;
    for (let i = 0; i < 5000 && atBottomCount < 3; i++) {
      if (cancelRequested) break;
      collect();
      setStatus(`모으는 중… 메시지 ${seen.size}개`);
      const before = scroller.scrollTop;
      scroller.scrollTop = before + step;
      await sleep(450);
      const atBottom =
        scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 5 ||
        scroller.scrollTop === before;
      atBottomCount = atBottom ? atBottomCount + 1 : 0;
    }
    collect();
    if (cancelRequested && !partialReason) partialReason = "사용자가 중간에 멈췄어요";

    return [...seen.values()].sort((a, b) => a.order - b.order);
  }

  function pageTitle() {
    return ((SITE === "snowchat" && snowTitle()) || (SITE === "gemini" && geminiTitle()) || document.title || "대화")
      .replace(/\s+/g, " ")
      .trim();
  }

  function toMarkdown(list) {
    const title = pageTitle();
    const now = new Date();
    const head = [
      `# ${title}`,
      "",
      `- 출처: ${SITE_LABEL}`,
      `- 주소: ${location.href}`,
      `- 저장 시각: ${now.toLocaleString("ko-KR")}`,
      `- 메시지 수: ${list.length}`,
      ...(partialReason ? [`- **주의: 대화 전체가 아니라 일부만 저장됨 (${partialReason})**`] : []),
      ...(skippedNotes ? [`- 제외: "여기까지의 대화를 요약했습니다" 표시 ${skippedNotes}개 (메시지가 아님)`] : []),
      `- 수집 방식: ${captureMethod} (E2K 대화 저장 프로토타입 v0.8)`,
      "",
      "---",
      "",
    ];
    const body = list.map((m, i) => {
      const who = m.role === "user" ? "나" : "AI";
      return `## [${i + 1}] ${who}\n\n${m.text}\n`;
    });
    return head.join("\n") + body.join("\n");
  }

  function download(text) {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");
    const safe = pageTitle().replace(/[\\/:*?"<>|]/g, "").slice(0, 40).trim();
    const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `E2K_${safe || "대화"}_${stamp}.md`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 1000);
  }

  // ---------- 화면 버튼 ----------

  function mountButton() {
    if (document.getElementById("e2k-capture-btn")) return;
    const btn = document.createElement("button");
    btn.id = "e2k-capture-btn";
    btn.textContent = "E2K 대화 저장";
    Object.assign(btn.style, {
      position: "fixed",
      right: "16px",
      bottom: "88px",
      zIndex: "2147483647",
      padding: "8px 12px",
      borderRadius: "999px",
      border: "1px solid #c9c9c9",
      background: "#ffffff",
      color: "#222",
      font: "13px/1.2 system-ui, sans-serif",
      boxShadow: "0 2px 8px rgba(0,0,0,.15)",
      cursor: "pointer",
    });
    const setStatus = (t) => (btn.textContent = t);

    btn.addEventListener("click", async () => {
      if (btn.dataset.busy) {
        // 저장 중에 다시 누르면: 지금까지 모은 것만 저장하고 멈춘다
        cancelRequested = true;
        setStatus("멈추는 중… 모은 만큼 저장해요");
        return;
      }
      cancelRequested = false;
      partialReason = null;
      skippedNotes = 0;
      captureMethod = "화면에 표시된 원문을 스크롤하며 수집";
      btn.dataset.busy = "1";
      try {
        const list = await capture(setStatus);
        const users = list.filter((m) => m.role === "user").length;
        const ais = list.length - users;
        if (users && !ais) {
          partialReason = "AI 답변을 하나도 찾지 못했어요. 화면 구조가 바뀌었을 수 있으니 이 파일은 쓰지 말고 알려 주세요";
          alert("E2K 대화 저장: 내 메시지만 찾고 AI 답변은 찾지 못했어요. 파일 맨 위에 주의 표시를 남겼어요.");
        } else if (ais && !users) {
          partialReason = "내 메시지를 하나도 찾지 못했어요. 화면 구조가 바뀌었을 수 있으니 이 파일은 쓰지 말고 알려 주세요";
          alert("E2K 대화 저장: AI 답변만 찾고 내 메시지는 찾지 못했어요. 파일 맨 위에 주의 표시를 남겼어요.");
        }
        const md = toMarkdown(list);
        download(md);
        try {
          await navigator.clipboard.writeText(md);
          setStatus(`${partialReason ? "일부만 저장" : "저장 완료"} · ${list.length}개 (클립보드에도 복사됨)`);
        } catch {
          setStatus(`${partialReason ? "일부만 저장" : "저장 완료"} · ${list.length}개`);
        }
      } catch (e) {
        alert("E2K 대화 저장: " + e.message);
        setStatus("E2K 대화 저장");
      } finally {
        delete btn.dataset.busy;
        setTimeout(() => !btn.dataset.busy && setStatus("E2K 대화 저장"), 6000);
      }
    });
    document.body.appendChild(btn);
  }

  mountButton();
  // 화면 전환(새 대화 열기 등) 뒤에도 버튼 유지
  new MutationObserver(() => mountButton()).observe(document.body, { childList: true });
})();
